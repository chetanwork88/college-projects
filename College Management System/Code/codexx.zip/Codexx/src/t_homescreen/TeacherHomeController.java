/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package t_homescreen;

import codexx.Codexx;
import com.mysql.jdbc.Connection;
import com.mysql.jdbc.Statement;
import java.io.IOException;
import java.net.URL;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ResourceBundle;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.ComboBox;
import javafx.scene.control.TextField;
import javafx.scene.image.ImageView;
import javafx.scene.layout.AnchorPane;
import javafx.stage.Stage;
import javax.swing.JOptionPane;

/**
 * FXML Controller class
 *
 * @author Chetan
 */
public class TeacherHomeController implements Initializable {

    @FXML
    private ComboBox<String> cb_attend_dept;
    @FXML
    private ComboBox<String> cb_attend_course;
    @FXML
    private TextField tf_atten_rollno;
    @FXML
    private ComboBox<String> cb_result_dept;
    @FXML
    private ComboBox<String> cb_result_course;
    @FXML
    private ImageView Anch;
    @FXML
    private TextField tf_attend_attend;
    @FXML
    private TextField tf_result_rollno;
    @FXML
    private TextField tf_result_marks;
    @FXML
    private ComboBox<String> cb_attend_subject;
    @FXML
    private ComboBox<String> cb_result_subject;
    @FXML
    private ComboBox<String> cb_library;
    @FXML
    private AnchorPane ActionByRollno;

    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        try {
            // TODO
            
            cb_attend_dept.getItems().addAll("CS", "IT", "Mech", "ENTC", "ETX", "Civil", "Chem");
            cb_attend_course.getItems().addAll("First Year", "Second Year", "Third Year", "Fourth Year");
            cb_result_dept.getItems().addAll("CS", "IT", "Mech", "ENTC", "ETX", "Civil", "Chem");
            cb_result_course.getItems().addAll("First Year", "Second Year", "Third Year", "Fourth Year");
            
            // cb_library.getItems().addAll("C", "Data structures", "Chemistry", "Digital Electronics", "Python", "Basic Electrical Enginnering", "Civil", "Thermodynamics", "C++", "Java", "Microprocessor", "Compiler Design", "Material Science");
            
            //Library search book initialize combobox 
            
            Connection con = null;
            String url1 = "jdbc:mysql://localhost:3306/";
            String db = "codex";
            String driver = "com.mysql.jdbc.Driver";
            String user = "CHETAN";
            String pass = "Micro@123";
            
            
            
            con = (Connection) DriverManager.getConnection(url1 + db, user, pass);
            Statement st = (Statement) con.createStatement();
            ResultSet res= st.executeQuery("select bname from library ;");
            while(res.next())
                    {
                        cb_library.getItems().addAll(res.getString(1));
                    }
        } catch (SQLException ex) {
            Logger.getLogger(TeacherHomeController.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    @FXML
    private void ActionBySignOut(ActionEvent event) {

        Parent root = null;
        try {
            root = FXMLLoader.load(getClass().getResource("/codexx/MainFrame.fxml"));

            Scene scene = new Scene(root);
            Stage stage = new Stage();
            stage.setScene(scene);
            Anch.getScene().getWindow().hide();
            stage.show();

        } catch (IOException ex) {
            Logger.getLogger(Codexx.class.getName()).log(Level.SEVERE, null, ex);
        }

    }

    @FXML
    private void ActionByNoSignOut(ActionEvent event) {

        Parent root = null;
        try {
            root = FXMLLoader.load(getClass().getResource("/t_homescreen/TeacherHome.fxml"));

            Scene scene = new Scene(root);
            Stage stage = new Stage();
            stage.setScene(scene);
            Anch.getScene().getWindow().hide();
            stage.show();

        } catch (IOException ex) {
            Logger.getLogger(Codexx.class.getName()).log(Level.SEVERE, null, ex);
        }

    }

    @FXML
    private void ActionByUpdateAttendence(ActionEvent event) {

        String attend_dept = cb_attend_dept.getValue();
        String attend_course = cb_attend_course.getValue();
        String attend_subject = cb_attend_subject.getValue();
        String rollno = tf_atten_rollno.getText();
        String attend = tf_attend_attend.getText();

        Connection con = null;
        String url = "jdbc:mysql://localhost:3306/";;
        String db = "codex";
        String driver = "com.mysql.jdbc.Driver";
        String user = "CHETAN";
        String pass = "Micro@123";

        try {
            Class.forName(driver);
            con = (Connection) DriverManager.getConnection(url + db, user, pass);
            Statement st = (Statement) con.createStatement();

            // int k = st.executeUpdate("insert into login(email) values('" + email + "')");
            int k = st.executeUpdate("insert into attendence(dept,course,subject,Roll_no,attendence) values('" + attend_dept + "','" + attend_course + "','" + attend_subject + "','" + rollno + "','" + attend + "');");
            JOptionPane.showMessageDialog(null, "Attendence updated successfully .");

            Parent root = null;
            try {
                root = FXMLLoader.load(getClass().getResource("/t_homescreen/TeacherHome.fxml"));

                Scene scene = new Scene(root);
                Stage stage = new Stage();
                stage.setScene(scene);
                Anch.getScene().getWindow().hide();
                stage.show();

            } catch (IOException ex) {
                Logger.getLogger(Codexx.class.getName()).log(Level.SEVERE, null, ex);
            }
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "Enter valid credentials .");

        }

    }

    @FXML
    private void ActionByUpdateResult(ActionEvent event) {

        String result_dept = cb_result_dept.getValue();
        String result_course = cb_result_course.getValue();
        String result_subject = cb_result_subject.getValue();
        String rollno = tf_result_rollno.getText();
        String marks = tf_result_marks.getText();

        Connection con = null;
        String url = "jdbc:mysql://localhost:3306/";;
        String db = "codex";
        String driver = "com.mysql.jdbc.Driver";
        String user = "CHETAN";
        String pass = "Micro@123";

        try {
            Class.forName(driver);
            con = (Connection) DriverManager.getConnection(url + db, user, pass);
            Statement st = (Statement) con.createStatement();

            // int k = st.executeUpdate("insert into login(email) values('" + email + "')");
            int k = st.executeUpdate("insert into result(dept,course,subject,Roll_no,marks) values('" + result_dept + "','" + result_course + "','" + result_subject + "','" + rollno + "','" + marks + "');");
            JOptionPane.showMessageDialog(null, "Marks updated successfully .");

            Parent root = null;
            try {
                root = FXMLLoader.load(getClass().getResource("/t_homescreen/TeacherHome.fxml"));

                Scene scene = new Scene(root);
                Stage stage = new Stage();
                stage.setScene(scene);
                Anch.getScene().getWindow().hide();
                stage.show();

            } catch (IOException ex) {
                Logger.getLogger(Codexx.class.getName()).log(Level.SEVERE, null, ex);
            }
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "Enter valid credentials .");
        }

    }

    @FXML
    private void ActionBySearchBook(ActionEvent event) throws SQLException {

        String book = cb_library.getValue();
        String quantity = "1";
        Connection con = null;
        String url = "jdbc:mysql://localhost:3306/";;
        String db = "codex";
        String driver = "com.mysql.jdbc.Driver";
        String user = "CHETAN";
        String pass = "Micro@123";

        try {
            //Class.forName(driver);
            con = (Connection) DriverManager.getConnection(url + db, user, pass);
            Statement st = (Statement) con.createStatement();

          
            ResultSet us = st.executeQuery("select qty from library where bname = '" + book + "';");
            if (us.next()) {
              
                if (Integer.parseInt(us.getString(1)) > 0) {

                    JOptionPane.showMessageDialog(null, "Book Is Avaialable In Library...");
                } 
                else {          
                    JOptionPane.showMessageDialog(null, "Book Is Not Avaialable In Library...");
                }
            } else {
                JOptionPane.showMessageDialog(null, "Enter Correct Book Name");
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    @FXML
    private void ActionByCourse(ActionEvent event) {

        //cb_attend_subject.getItems ().addAll("M-1","Physics","Chemistry","Microprocessor","Electrical","Electronics","Civil","Thermodynamics","FPL-1","DBMS","CAD");
        cb_attend_subject.getItems().clear();
        cb_attend_subject.setDisable(false);

        if (cb_attend_dept.getValue().equals("CS")) {
            if (cb_attend_course.getValue().equals("First Year")) {
                cb_attend_subject.getItems().addAll("M-1", "Physics", "Chemistry", "Graphics", "Electrical", "Electronics", "Civil", "M-2", "FPL-1", "FPL-2", "CAD");
            } else if (cb_attend_course.getValue().equals("Second Year")) {
                cb_attend_subject.getItems().addAll("M-3", "COA", "Microprocessor", "Computer Graphics", "DSA", "ADS", "OOP", "DELD", "PPL");
            } else if (cb_attend_course.getValue().equals("Third Year")) {
                cb_attend_subject.getItems().addAll("TOC", "CN", "ISEE", "SEPM", "Operating System", "Alogoritms", "DBMS");
            } else if (cb_attend_course.getValue().equals("Fourth Year")) {
                cb_attend_subject.getItems().addAll("Data Mining", "Compiler Design", "Software Design", "Hardware Design", "Image Processing");
            }
        } else if (cb_attend_dept.getValue().equals("IT")) {
            if (cb_attend_course.getValue().equals("First Year")) {
                cb_attend_subject.getItems().addAll("M-1", "Physics", "Chemistry", "Graphics", "Electrical", "Electronics", "Civil", "M-2", "FPL-1", "FPL-2", "CAD");
            } else if (cb_attend_course.getValue().equals("Second Year")) {
                cb_attend_subject.getItems().addAll("M-3", "COA", "Microprocessor", "Computer Graphics", "DSA", "ADS", "OOP", "DELD", "PPL");
            } else if (cb_attend_course.getValue().equals("Third Year")) {
                cb_attend_subject.getItems().addAll("TOC", "CN", "Human-Computer Interaction ", "SEPM", "Operating System", "Cloud Computing", "DBMS");
            } else if (cb_attend_course.getValue().equals("Fourth Year")) {
                cb_attend_subject.getItems().addAll("Distributed System", "Compiler Design", "Software Design", "Hardware Design", "Image Processing");
            }
        } else if (cb_attend_dept.getValue().equals("Mech")) {
            if (cb_attend_course.getValue().equals("First Year")) {
                cb_attend_subject.getItems().addAll("M-1", "Physics", "Chemistry", "Graphics", "Electrical", "Electronics", "Civil", "M-2", "FPL-1", "Basic Mechanical", "CAD");
            } else if (cb_attend_course.getValue().equals("Second Year")) {
                cb_attend_subject.getItems().addAll("M-3", "Manfacturing Processes", "Thermodynamics", "Material Science", "TOM", "SOM");
            } else if (cb_attend_course.getValue().equals("Third Year")) {
                cb_attend_subject.getItems().addAll("Heat Transfer", "Hydraulics", "TurboMachines", "Mechatronics");
            } else if (cb_attend_course.getValue().equals("Fourth Year")) {
                cb_attend_subject.getItems().addAll("Refrigeration", "CAD", "Machine Dynamics", "Mechanical System Design", " PowerPlant Design");
            }
        } else if (cb_attend_dept.getValue().equals("ENTC")) {
            if (cb_attend_course.getValue().equals("First Year")) {
                cb_attend_subject.getItems().addAll("M-1", "Physics", "Chemistry", "Graphics", "Electrical", "Electronics", "Civil", "M-2", "FPL-1", "FPL-2", "CAD");
            } else if (cb_attend_course.getValue().equals("Second Year")) {
                cb_attend_subject.getItems().addAll("M-3", "Integrated Circuits", "Control Systems", "Computer Graphics", "Analog Communication", "OOP", "DELD");
            } else if (cb_attend_course.getValue().equals("Third Year")) {
                cb_attend_subject.getItems().addAll("TOC", "CN", "ISEE", "SEPM", "Operating System", "Alogoritms", "DBMS");
            } else if (cb_attend_course.getValue().equals("Fourth Year")) {
                cb_attend_subject.getItems().addAll("Microwave Engineering", "Computer Networks ", "VLSI Design & Technology ", "Mobile Communication", "Broadband Communication ");
            }
        } else if (cb_attend_dept.getValue().equals("ETX")) {
            if (cb_attend_course.getValue().equals("First Year")) {
                cb_attend_subject.getItems().addAll("M-1", "Physics", "Chemistry", "Graphics", "Electrical", "Electronics", "Civil", "M-2", "FPL-1", "FPL-2", "CAD");
            } else if (cb_attend_course.getValue().equals("Second Year")) {
                cb_attend_subject.getItems().addAll("M-3", "signal and modelling", "Eletrical circuits", "Computer Graphics","ADS", "OOP", "DELD");
            } else if (cb_attend_course.getValue().equals("Third Year")) {
                cb_attend_subject.getItems().addAll("Data Communication", "Network Synthesis", "EMPD and NS Lab", "Instrumentation Systems", "Embedded Processors");
            } else if (cb_attend_course.getValue().equals("Fourth Year")) {
                cb_attend_subject.getItems().addAll("VLSI Design", "Electronics system Design ", "Advanced Power Electronics", "Computer Network", "Process Automation ");
            }
        } else if (cb_attend_dept.getValue().equals("Chem")) {
            if (cb_attend_course.getValue().equals("First Year")) {
                cb_attend_subject.getItems().addAll("M-1", "Physics", "Chemistry", "Graphics", "Electrical", "Electronics", "Civil", "M-2", "FPL-1", "FPL-2", "CAD");
            } else if (cb_attend_course.getValue().equals("Second Year")) {
                cb_attend_subject.getItems().addAll("M-3", "Chemistry-I", "Fluid Mechanics", "Heat Transfer", "Principles of Design", "1 Mechanical Operations", "Process Calculations");
            } else if (cb_attend_course.getValue().equals("Third Year")) {
                cb_attend_subject.getItems().addAll("Mass Transfer I", "Chemical Engineering mathematics", "Chemical Process technology", "Transport Phenomena", "Mass Transfer II ", "Alogoritms");
            } else if (cb_attend_course.getValue().equals("Fourth Year")) {
                cb_attend_subject.getItems().addAll("Process Dynamics and Control ", "Chemical Reaction Engineering II", "Chemical Engineering Design II ", " Process Modeling and Simulation", "Process Engineering Costing & Plant\n" +
"Design");
            }
        } else if (cb_attend_dept.getValue().equals("Civil")) {
            if (cb_attend_course.getValue().equals("First Year")) {
                cb_attend_subject.getItems().addAll("M-1", "Physics", "Chemistry", "Graphics", "Electrical", "Electronics", "Civil", "M-2", "FPL-1", "FPL-2", "CAD");
            } else if (cb_attend_course.getValue().equals("Second Year")) {
                cb_attend_subject.getItems().addAll("M-3", "Surveying", "Geological Enginnering", "SOM", "TOM", "Fluid mechanics");
            } else if (cb_attend_course.getValue().equals("Third Year")) {
                cb_attend_subject.getItems().addAll("Advanced Surveying", "Structural design", "Foundation Engineering", "Structural Analysis", "Hydrology");
            } else if (cb_attend_course.getValue().equals("Fourth Year")) {
                cb_attend_subject.getItems().addAll("Transporation Engg", "Structural  Design 2", "Foundation Engineering 2", "Quantity Surveying", "Environmnetal Engg ");
            }
        }

    }

    @FXML
    private void ActionByDept(ActionEvent event) {
        cb_attend_course.setDisable(false);

    }

    @FXML
    private void ActionBySubject(ActionEvent event) {

        tf_atten_rollno.setDisable(false);
        tf_attend_attend.setDisable(false);
    }

    @FXML
    private void ActionByDeptResult(ActionEvent event) {

        cb_result_course.setDisable(false);
    }

    @FXML
    private void ActionByCourseResult(ActionEvent event) {

        cb_result_subject.getItems().clear();
        cb_result_subject.setDisable(false);

        if (cb_result_dept.getValue().equals("CS")) {
            if (cb_result_course.getValue().equals("First Year")) {
                cb_result_subject.getItems().addAll("M-1", "Physics", "Chemistry", "Graphics", "Electrical", "Electronics", "Civil", "M-2", "FPL-1", "FPL-2", "CAD");
            } else if (cb_result_course.getValue().equals("Second Year")) {
                cb_result_subject.getItems().addAll("M-3", "COA", "Microprocessor", "Computer Graphics", "DSA", "ADS", "OOP", "DELD", "PPL");
            } else if (cb_result_course.getValue().equals("Third Year")) {
                cb_result_subject.getItems().addAll("TOC", "CN", "ISEE", "SEPM", "Operating System", "Alogoritms", "DBMS");
            } else if (cb_result_course.getValue().equals("Fourth Year")) {
                cb_result_subject.getItems().addAll("Data Mining", "Compiler Design", "Software Design", "Hardware Design", "Image Processing");
            }
        } else if (cb_result_dept.getValue().equals("IT")) {
            if (cb_result_course.getValue().equals("First Year")) {
                cb_result_subject.getItems().addAll("M-1", "Physics", "Chemistry", "Graphics", "Electrical", "Electronics", "Civil", "M-2", "FPL-1", "FPL-2", "CAD");
            } else if (cb_result_course.getValue().equals("Second Year")) {
                cb_result_subject.getItems().addAll("M-3", "COA", "Microprocessor", "Computer Graphics", "DSA", "ADS", "OOP", "DELD", "PPL");
            } else if (cb_result_course.getValue().equals("Third Year")) {
                cb_result_subject.getItems().addAll("TOC", "CN", "Human-Computer Interaction ", "SEPM", "Operating System", "Cloud Computing", "DBMS");
            } else if (cb_result_course.getValue().equals("Fourth Year")) {
                cb_result_subject.getItems().addAll("Distributed System", "Compiler Design", "Software Design", "Hardware Design", "Image Processing");
            }
        } else if (cb_result_dept.getValue().equals("Mech")) {
            if (cb_result_course.getValue().equals("First Year")) {
                cb_result_subject.getItems().addAll("M-1", "Physics", "Chemistry", "Graphics", "Electrical", "Electronics", "Civil", "M-2", "FPL-1", "Basic Mechanical", "CAD");
            } else if (cb_result_course.getValue().equals("Second Year")) {
                cb_result_subject.getItems().addAll("M-3", "Manfacturing Processes", "Thermodynamics", "Material Science", "TOM", "SOM");
            } else if (cb_result_course.getValue().equals("Third Year")) {
                cb_result_subject.getItems().addAll("Heat Transfer", "Hydraulics", "TurboMachines", "Mechatronics");
            } else if (cb_result_course.getValue().equals("Fourth Year")) {
                cb_result_subject.getItems().addAll("Refrigeration", "CAD", "Machine Dynamics", "Mechanical System Design", " PowerPlant Design");
            }
        } else if (cb_result_dept.getValue().equals("ENTC")) {
            if (cb_result_course.getValue().equals("First Year")) {
                cb_result_subject.getItems().addAll("M-1", "Physics", "Chemistry", "Graphics", "Electrical", "Electronics", "Civil", "M-2", "FPL-1", "FPL-2", "CAD");
            } else if (cb_result_course.getValue().equals("Second Year")) {
                cb_result_subject.getItems().addAll("M-3", "Integrated Circuits", "Control Systems", "Computer Graphics", "Analog Communication", "OOP", "DELD");
            } else if (cb_result_course.getValue().equals("Third Year")) {
                cb_result_subject.getItems().addAll("TOC", "CN", "ISEE", "SEPM", "Operating System", "Alogoritms", "DBMS");
            } else if (cb_result_course.getValue().equals("Fourth Year")) {
                cb_result_subject.getItems().addAll("Microwave Engineering", "Computer Networks ", "VLSI Design & Technology ", "Mobile Communication", "Broadband Communication ");
            }
        } else if (cb_result_dept.getValue().equals("ETX")) {
            if (cb_result_course.getValue().equals("First Year")) {
                cb_result_subject.getItems().addAll("M-1", "Physics", "Chemistry", "Graphics", "Electrical", "Electronics", "Civil", "M-2", "FPL-1", "FPL-2", "CAD");
            } else if (cb_result_course.getValue().equals("Second Year")) {
                cb_result_subject.getItems().addAll("M-3", "signal and modelling", "Eletrical circuits", "Computer Graphics","ADS", "OOP", "DELD");
            } else if (cb_result_course.getValue().equals("Third Year")) {
                cb_result_subject.getItems().addAll("Data Communication", "Network Synthesis", "EMPD and NS Lab", "Instrumentation Systems", "Embedded Processors");
            } else if (cb_result_course.getValue().equals("Fourth Year")) {
                cb_result_subject.getItems().addAll("VLSI Design", "Electronics system Design ", "Advanced Power Electronics", "Computer Network", "Process Automation ");
            }
        } else if (cb_result_dept.getValue().equals("Chem")) {
            if (cb_result_course.getValue().equals("First Year")) {
                cb_result_subject.getItems().addAll("M-1", "Physics", "Chemistry", "Graphics", "Electrical", "Electronics", "Civil", "M-2", "FPL-1", "FPL-2", "CAD");
            } else if (cb_result_course.getValue().equals("Second Year")) {
                cb_result_subject.getItems().addAll("M-3", "Chemistry-I", "Fluid Mechanics", "Heat Transfer", "Principles of Design", "1 Mechanical Operations", "Process Calculations");
            } else if (cb_result_course.getValue().equals("Third Year")) {
                cb_result_subject.getItems().addAll("Mass Transfer I", "Chemical Engineering mathematics", "Chemical Process technology", "Transport Phenomena", "Mass Transfer II ", "Alogoritms");
            } else if (cb_result_course.getValue().equals("Fourth Year")) {
                cb_result_subject.getItems().addAll("Process Dynamics and Control ", "Chemical Reaction Engineering II", "Chemical Engineering Design II ", " Process Modeling and Simulation", "Process Engineering Costing & Plant\n" +
"Design");
            }
        } else if (cb_result_dept.getValue().equals("Civil")) {
            if (cb_result_course.getValue().equals("First Year")) {
                cb_result_subject.getItems().addAll("M-1", "Physics", "Chemistry", "Graphics", "Electrical", "Electronics", "Civil", "M-2", "FPL-1", "FPL-2", "CAD");
            } else if (cb_result_course.getValue().equals("Second Year")) {
                cb_result_subject.getItems().addAll("M-3", "Surveying", "Geological Enginnering", "SOM", "TOM", "Fluid mechanics");
            } else if (cb_result_course.getValue().equals("Third Year")) {
                cb_result_subject.getItems().addAll("Advanced Surveying", "Structural design", "Foundation Engineering", "Structural Analysis", "Hydrology");
            } else if (cb_result_course.getValue().equals("Fourth Year")) {
                cb_result_subject.getItems().addAll("Transporation Engg", "Structural  Design 2", "Foundation Engineering 2", "Quantity Surveying", "Environmnetal Engg ");
            }
        }
    }

    @FXML
    private void ActionBySubjectResult(ActionEvent event) {

        tf_result_rollno.setDisable(false);
        tf_result_marks.setDisable(false);
    }

}
