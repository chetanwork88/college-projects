/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package t_forgotpwd;

import codexx.Codexx;
import com.mysql.jdbc.Connection;
import com.mysql.jdbc.Statement;
import forgotpassword.Fp1Controller;
import java.io.IOException;
import java.net.URL;
import java.sql.DriverManager;
import java.util.ResourceBundle;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.PasswordField;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.AnchorPane;
import javafx.stage.Stage;
import javax.swing.JOptionPane;

/**
 * FXML Controller class
 *
 * @author Chetan
 */
public class TeacherFp2Controller implements Initializable {

    @FXML
    private AnchorPane Anch;
    @FXML
    private AnchorPane Anchor;
    @FXML
    private PasswordField tf_pwd;
    @FXML
    private PasswordField tf_cnfpwd;

    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
    }    

    @FXML
    private void ActionBySubmitTeacher(ActionEvent event) {
        
        String pwd = tf_pwd.getText();
        String cnfpwd = tf_cnfpwd.getText();
        if(pwd.equals(cnfpwd))
        {
        //=======databse insert

        
        Connection con = null;
String url = "jdbc:mysql://localhost:3306/";;
String db = "codex";
String driver = "com.mysql.jdbc.Driver";
String user = "CHETAN";
String pass = "Micro@123";
String user1="";
String pass1="";
try{
Class.forName(driver);
con = (Connection) DriverManager.getConnection(url+db, user, pass);
Statement st = (Statement) con.createStatement();
            

int k=st.executeUpdate("update t_login set password = '"+pwd+"' where email='"+TeacherFp1Controller.email1+"'; ");
JOptionPane.showMessageDialog(null,"Password updated successfully. ");
}
catch(Exception e){}
        
        //code for changing another slide
        Parent root=null;
        try {
              root = FXMLLoader.load(getClass().getResource("/t_login/TeacherLogin.fxml"));
            
             Scene scene = new Scene(root);
            Stage stage=new Stage();
            stage.setScene(scene);
           Anch.getScene().getWindow().hide();
            stage.show();

        } catch (IOException ex) {
            Logger.getLogger(Codexx.class.getName()).log(Level.SEVERE, null, ex);
        }
    }else
        {
            JOptionPane.showMessageDialog(null,"Password didn't matched");
        }
    }

    @FXML
    private void ActionByLogin(ActionEvent event) {
        
        Parent root=null;
        try {
              root = FXMLLoader.load(getClass().getResource("/codexx/MainFrame.fxml"));
            
             Scene scene = new Scene(root);
            Stage stage=new Stage();
            stage.setScene(scene);
           Anchor.getScene().getWindow().hide();
            stage.show();

        } catch (IOException ex) {
            Logger.getLogger(Codexx.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    
}
