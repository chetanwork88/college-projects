/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package signup;

import codexx.Codexx;
import com.mysql.jdbc.Connection;
import com.mysql.jdbc.Statement;
import java.io.IOException;
import java.net.URL;
import java.sql.DriverManager;
import java.time.Clock;
import java.util.Properties;
import java.util.Random;
import java.util.ResourceBundle;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.TextField;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.AnchorPane;
import javafx.stage.Stage;
import javax.mail.Message;
import javax.mail.PasswordAuthentication;
import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeMessage;
import javax.swing.JOptionPane;

/**
 * FXML Controller class
 *
 * @author Chetan
 */
public class Step1Controller implements Initializable {

    @FXML
    private AnchorPane Anch;
    @FXML
    private TextField tf_email;
    @FXML
    private TextField tf_otp;
    public static  String email;
    public String strOtp = "";
    @FXML
    private AnchorPane Anchor;
    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
    }

    @FXML
    private void ActionbySendOTP(MouseEvent event) {
        email = tf_email.getText();
        String sub = "OTP for login";
        //====== code for generating otp;

        String numbers = "0123456789";

        // Using random method
        Random rndm_method = new Random();

        char[] otp = new char[4];

        for (int i = 0; i < 4; i++) {
            // Use of charAt() method : to get character value
            // Use of nextInt() as it is scanning the value as int
            otp[i]
                    = numbers.charAt(rndm_method.nextInt(numbers.length()));
        }
        
        for (Character c : otp) {
            strOtp += c.toString();
        }
        //==================
        //int msg=4545; 
        final String user = "indiacodex@gmail.com";
        final String pass = "xedocaidni";

        //create an instance of Properties Class   
        Properties props = new Properties();

        /* Specifies the IP address of your default mail server
     	   for e.g if you are using gmail server as an email sever
           you will pass smtp.gmail.com as value of mail.smtp host. 
           As shown here in the code. 
           Change accordingly, if your email id is not a gmail id
         */
        props.put("mail.smtp.host", "smtp.gmail.com");
        //below mentioned mail.smtp.port is optional
        props.put("mail.smtp.port", "587");
        props.put("mail.smtp.auth", "true");
        props.put("mail.smtp.starttls.enable", "true");

        /* Pass Properties object(props) and Authenticator object   
           for authentication to Session instance 
         */
        Session session = Session.getInstance(props, new javax.mail.Authenticator() {
            protected PasswordAuthentication getPasswordAuthentication() {
                return new PasswordAuthentication(user, pass);
            }
        });

        try {

            /* Create an instance of MimeMessage, 
 	      it accept MIME types and headers 
             */
            MimeMessage message = new MimeMessage(session);
            message.setFrom(new InternetAddress(user));
            message.addRecipient(Message.RecipientType.TO, new InternetAddress(email));
            message.setSubject(sub);
            message.setText(strOtp);

            /* Transport class is used to deliver the message to the recipients */
            Transport.send(message);

            JOptionPane.showMessageDialog(null, "OTP Sent Successfully.");
            System.out.println(strOtp);
            
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null,"Enter valid Email");
        }
            
        //==
    }

    @FXML
    private void ActionByNext(MouseEvent event) {
        //code for entering email in the database
        if (strOtp.equals(tf_otp.getText())) {
            Connection con = null;
String url = "jdbc:mysql://localhost:3306/";;
        String db = "codex";
        String driver = "com.mysql.jdbc.Driver";
        String user = "CHETAN";
        String pass = "Micro@123";
        String user1 = "";
        String pass1 = "";
        try {
            Class.forName(driver);
            con = (Connection) DriverManager.getConnection(url + db, user, pass);
            Statement st = (Statement) con.createStatement();

            int k = st.executeUpdate("insert into login(email) values('" + email + "')");
            JOptionPane.showMessageDialog(null, "E-mail confirmed.");

        } catch (Exception e) {
        }

        // code for opening another slide
       // String k = tf_otp.getText();
       
            Parent root = null;
            try {
                root = FXMLLoader.load(getClass().getResource("/signup/step2.fxml"));

                Scene scene = new Scene(root);
                Stage stage = new Stage();
                stage.setScene(scene);
                Anch.getScene().getWindow().hide();
                stage.show();

            } catch (IOException ex) {
                Logger.getLogger(Codexx.class.getName()).log(Level.SEVERE, null, ex);
            }

        } else {
            JOptionPane.showMessageDialog(null, "Enter valid OTP ");
        }
    }

    @FXML
    private void ActionByLogin(ActionEvent event) {
        
        Parent root=null;
        try {
              root = FXMLLoader.load(getClass().getResource("/codexx/MainFrame.fxml"));
            
             Scene scene = new Scene(root);
            Stage stage=new Stage();
            stage.setScene(scene);
           Anchor.getScene().getWindow().hide();
            stage.show();

        } catch (IOException ex) {
            Logger.getLogger(Codexx.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

}
