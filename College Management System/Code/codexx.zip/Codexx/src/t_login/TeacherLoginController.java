/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package t_login;

import codexx.Codexx;
import com.mysql.jdbc.Connection;
import com.mysql.jdbc.Statement;
import java.io.IOException;
import java.net.URL;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.util.ResourceBundle;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.AnchorPane;
import javafx.stage.Stage;
import javax.swing.JOptionPane;

/**
 * FXML Controller class
 *
 * @author Chetan
 */
public class TeacherLoginController implements Initializable {

    @FXML
    private AnchorPane rootPane;
    @FXML
    private AnchorPane rootPane1;
    @FXML
    private AnchorPane rootPane2;
    @FXML
    private TextField tf_email;
    @FXML
    private PasswordField tf_pwd;

    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
    }   

   

    @FXML
    private void ActionBySignUpTeacher(ActionEvent event) {
        
        Parent root=null;
        try {
                        root = FXMLLoader.load(getClass().getResource("/t_signup/TeacherStep1.fxml"));
            
            Scene scene = new Scene(root);
            Stage stage=new Stage();
            stage.setScene(scene);
            rootPane1.getScene().getWindow().hide();
            stage.show();

        } catch (IOException ex) {
            Logger.getLogger(Codexx.class.getName()).log(Level.SEVERE, null, ex);
        }
        
    }


    @FXML
    private void ActionByChangeUserTeacher(ActionEvent event) {
        
        Parent root=null;
        try {
                        root = FXMLLoader.load(getClass().getResource("/codexx/MainFrame.fxml"));
            
            Scene scene = new Scene(root);
            Stage stage=new Stage();
            stage.setScene(scene);
            rootPane1.getScene().getWindow().hide();
            stage.show();

        } catch (IOException ex) {
            Logger.getLogger(Codexx.class.getName()).log(Level.SEVERE, null, ex);
        }
    } 

    @FXML
    private void ActionByForgotPwdTeacher(ActionEvent event) {
        
        Parent root=null;
        try {
                        root = FXMLLoader.load(getClass().getResource("/t_forgotpwd/TeacherFp1.fxml"));
            
            Scene scene = new Scene(root);
            Stage stage=new Stage();
            stage.setScene(scene);
            rootPane1.getScene().getWindow().hide();
            stage.show();

        } catch (IOException ex) {
            Logger.getLogger(Codexx.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    @FXML
    private void ActionByLoginTeacher(ActionEvent event) {
        
         String email = tf_email.getText();
        String pwd = tf_pwd.getText();

        Connection con = null;
        String url = "jdbc:mysql://localhost:3306/";;
        String db = "codex";
        String driver = "com.mysql.jdbc.Driver";
        String user = "CHETAN";
        String pass = "Micro@123";

        try {
            Class.forName(driver);
            con = (Connection) DriverManager.getConnection(url + db, user, pass);
            Statement st = (Statement) con.createStatement();

            // int k = st.executeUpdate("insert into login(email) values('" + email + "')");
//            int k = st.executeUpdate("insert into  civil(fname,mname,lname,contact_no,email,dob,address,city,state,course,fees) values('" + fname + "','" + mname + "','" + lname + "','" + contact + "','" + email + "','" + dob + "','" + address + "','" + city + "','" + state + "','" + course + "','" + fees + "');");
            ResultSet us = st.executeQuery("select email from t_login where email = '" + email + "';");
            if (us.next()) {
                ResultSet res = st.executeQuery("select * from t_login where email = '" + email + "';");

                if (res.next()) {
                    // System.out.println("hello");
                    if (res.getString(2).equals(pwd)) {

                          JOptionPane.showMessageDialog(null,"Login Successful...");
                        Parent root = null;
                        try {
                            root = FXMLLoader.load(getClass().getResource("/t_homescreen/TeacherHome.fxml"));
                            Scene scene = new Scene(root);
                            Stage stage = new Stage();
                            stage.setScene(scene);
                            rootPane2.getScene().getWindow().hide();
                            stage.show();

                        } catch (IOException ex) {
                            Logger.getLogger(Codexx.class.getName()).log(Level.SEVERE, null, ex);
                        }
                    } else {          //login error
                        JOptionPane.showMessageDialog(null, "Enter valid Password");
                    }
                }

            }
            else{
                        JOptionPane.showMessageDialog(null, "Enter valid Username");
            }
        }
        catch(Exception e){
            e.printStackTrace();
        }
        
    }

    
}
