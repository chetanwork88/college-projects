/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package homescreen;

import codexx.Codexx;
import com.mysql.jdbc.Connection;
import com.mysql.jdbc.Statement;
import java.io.IOException;
import java.net.URL;
import java.sql.DriverManager;
import java.time.LocalDate;
import java.util.ResourceBundle;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.ComboBox;
import javafx.scene.control.DatePicker;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;
import javafx.stage.Stage;
import javax.swing.JOptionPane;

/**
 * FXML Controller class
 *
 * @author Chetan
 */


public class AdmissionFormController implements Initializable {

    /**
     * Initializes the controller class.
     */
       
    @FXML
    private ComboBox<String> cb_branch;
    @FXML
    private ComboBox<String> cb_course;
    @FXML
    private TextField tf_email;
    @FXML
    private TextField tf_mname;
    @FXML
    private TextField tf_lname;
    @FXML
    private TextField tf_contact_no;
    @FXML
    private TextField tf_state;
    @FXML
    private TextArea tf_address;
    @FXML
    private TextField tf_city;
    @FXML
    private TextField tf_fname;
    @FXML
    private TextField tf_fees;
    @FXML
    private DatePicker tf_dob;
    
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
//

cb_branch.getItems ().addAll("CS","IT","Mech","ENTC","ETX","Civil","Chem");
cb_course.getItems ().addAll("First Year","Second Year","Third Year","Fourth Year");
 
    }    

    @FXML
    private void ActionBySubmitButton(ActionEvent event) {
        String fname=tf_fname.getText();
        String mname=tf_mname.getText();
        String lname=tf_lname.getText();
        String contact=tf_contact_no.getText();
        String email=tf_email.getText();
        LocalDate dob =tf_dob.getValue();
        String address=tf_address.getText();
        String city=tf_city.getText();
        String state=tf_state.getText();
        String fees=tf_fees.getText();
        
        String branch=cb_branch.getValue();
        String course=cb_course.getValue();

        if(branch.equals("CS"))
        {
            Connection con = null;
        String url = "jdbc:mysql://localhost:3306/";;
        String db = "codex";
        String driver = "com.mysql.jdbc.Driver";
        String user = "CHETAN";
        String pass = "Micro@123";
     
        try {
            Class.forName(driver);
            con = (Connection) DriverManager.getConnection(url + db, user, pass);
            Statement st = (Statement) con.createStatement();

           // int k = st.executeUpdate("insert into login(email) values('" + email + "')");
            int k = st.executeUpdate("insert into cs(fname,mname,lname,contact_no,email,dob,address,city,state,course,fees) values('" + fname + "','" + mname + "','" + lname + "','" + contact + "','" + email + "','" + dob + "','" + address + "','" + city + "','" + state + "','" + course + "','" + fees + "');");
            JOptionPane.showMessageDialog(null, "Data saved successfully .");
        } catch (Exception e) {
            e.printStackTrace();
        }
            
        }else if(branch.equals("IT"))
        {
            Connection con = null;
        String url = "jdbc:mysql://localhost:3306/";;
        String db = "codex";
        String driver = "com.mysql.jdbc.Driver";
        String user = "CHETAN";
        String pass = "Micro@123";
        String user1 = "";
        String pass1 = "";
        try {
            Class.forName(driver);
            con = (Connection) DriverManager.getConnection(url + db, user, pass);
            Statement st = (Statement) con.createStatement();

           // int k = st.executeUpdate("insert into login(email) values('" + email + "')");
            int k = st.executeUpdate("insert into  it(fname,mname,lname,contact_no,email,dob,address,city,state,course,fees) values('" + fname + "','" + mname + "','" + lname + "','" + contact + "','" + email + "','" + dob + "','" + address + "','" + city + "','" + state + "','" + course + "','" + fees + "');");
            JOptionPane.showMessageDialog(null, "Data saved successfully .");
            
            Parent root=null;
        try {
              root = FXMLLoader.load(getClass().getResource("/homescreen/Home.fxml"));
            
             Scene scene = new Scene(root);
            Stage stage=new Stage();
            stage.setScene(scene);
           cb_course.getScene().getWindow().hide();
            stage.show();

        } catch (IOException ex) {
            Logger.getLogger(Codexx.class.getName()).log(Level.SEVERE, null, ex);
        }
        } catch (Exception e) {
            e.printStackTrace();
        }
            
        }else if(branch.equals("Mech"))
        {
            Connection con = null;
        String url = "jdbc:mysql://localhost:3306/";;
        String db = "codex";
        String driver = "com.mysql.jdbc.Driver";
        String user = "CHETAN";
        String pass = "Micro@123";
        String user1 = "";
        String pass1 = "";
        try {
            Class.forName(driver);
            con = (Connection) DriverManager.getConnection(url + db, user, pass);
            Statement st = (Statement) con.createStatement();

           // int k = st.executeUpdate("insert into login(email) values('" + email + "')");
            int k = st.executeUpdate("insert into  mech(fname,mname,lname,contact_no,email,dob,address,city,state,course,fees) values('" + fname + "','" + mname + "','" + lname + "','" + contact + "','" + email + "','" + dob + "','" + address + "','" + city + "','" + state + "','" + course + "','" + fees + "');");
            JOptionPane.showMessageDialog(null, "Data saved successfully .");
            
             Parent root=null;
        try {
              root = FXMLLoader.load(getClass().getResource("/homescreen/Home.fxml"));
            
             Scene scene = new Scene(root);
            Stage stage=new Stage();
            stage.setScene(scene);
           cb_course.getScene().getWindow().hide();
            stage.show();

        } catch (IOException ex) {
            Logger.getLogger(Codexx.class.getName()).log(Level.SEVERE, null, ex);
        }
        
        } catch (Exception e) {
            e.printStackTrace();
        }
            
        }else if(branch.equals("ENTC"))
        {
            Connection con = null;
        String url = "jdbc:mysql://localhost:3306/";;
        String db = "codex";
        String driver = "com.mysql.jdbc.Driver";
        String user = "CHETAN";
        String pass = "Micro@123";
        String user1 = "";
        String pass1 = "";
        try {
            Class.forName(driver);
            con = (Connection) DriverManager.getConnection(url + db, user, pass);
            Statement st = (Statement) con.createStatement();

           // int k = st.executeUpdate("insert into login(email) values('" + email + "')");
            int k = st.executeUpdate("insert into  entc(fname,mname,lname,contact_no,email,dob,address,city,state,course,fees) values('" + fname + "','" + mname + "','" + lname + "','" + contact + "','" + email + "','" + dob + "','" + address + "','" + city + "','" + state + "','" + course + "','" + fees + "');");
            JOptionPane.showMessageDialog(null, "Data saved successfully .");
            
             Parent root=null;
        try {
              root = FXMLLoader.load(getClass().getResource("/homescreen/Home.fxml"));
            
             Scene scene = new Scene(root);
            Stage stage=new Stage();
            stage.setScene(scene);
           cb_course.getScene().getWindow().hide();
            stage.show();

        } catch (IOException ex) {
            Logger.getLogger(Codexx.class.getName()).log(Level.SEVERE, null, ex);
        }
        
        
        } catch (Exception e) {
            e.printStackTrace();
        }
            
        }else if(branch.equals("ETX"))
        {
            Connection con = null;
        String url = "jdbc:mysql://localhost:3306/";;
        String db = "codex";
        String driver = "com.mysql.jdbc.Driver";
        String user = "CHETAN";
        String pass = "Micro@123";
        String user1 = "";
        String pass1 = "";
        try {
            Class.forName(driver);
            con = (Connection) DriverManager.getConnection(url + db, user, pass);
            Statement st = (Statement) con.createStatement();

           // int k = st.executeUpdate("insert into login(email) values('" + email + "')");
            int k = st.executeUpdate("insert into  etx(fname,mname,lname,contact_no,email,dob,address,city,state,course,fees) values('" + fname + "','" + mname + "','" + lname + "','" + contact + "','" + email + "','" + dob + "','" + address + "','" + city + "','" + state + "','" + course + "','" + fees + "');");
            JOptionPane.showMessageDialog(null, "Data saved successfully .");
            
             Parent root=null;
        try {
              root = FXMLLoader.load(getClass().getResource("/homescreen/Home.fxml"));
            
             Scene scene = new Scene(root);
            Stage stage=new Stage();
            stage.setScene(scene);
           cb_course.getScene().getWindow().hide();
            stage.show();

        } catch (IOException ex) {
            Logger.getLogger(Codexx.class.getName()).log(Level.SEVERE, null, ex);
        }
        
        
        } catch (Exception e) {
        e.printStackTrace();
        }
            
        }else if(branch.equals("Civil"))
        {
            
            Connection con = null;
        String url = "jdbc:mysql://localhost:3306/";;
        String db = "codex";
        String driver = "com.mysql.jdbc.Driver";
        String user = "CHETAN";
        String pass = "Micro@123";
        try {
            Class.forName(driver);
            con = (Connection) DriverManager.getConnection(url + db, user, pass);
            Statement st = (Statement) con.createStatement();

           // int k = st.executeUpdate("insert into login(email) values('" + email + "')");
            int k = st.executeUpdate("insert into  civil(fname,mname,lname,contact_no,email,dob,address,city,state,course,fees) values('" + fname + "','" + mname + "','" + lname + "','" + contact + "','" + email + "','" + dob + "','" + address + "','" + city + "','" + state + "','" + course + "','" + fees + "');");
            JOptionPane.showMessageDialog(null, "Data saved successfully .");
            
             Parent root=null;
        try {
              root = FXMLLoader.load(getClass().getResource("/homescreen/Home.fxml"));
            
             Scene scene = new Scene(root);
            Stage stage=new Stage();
            stage.setScene(scene);
           cb_course.getScene().getWindow().hide();
            stage.show();

        } catch (IOException ex) {
            Logger.getLogger(Codexx.class.getName()).log(Level.SEVERE, null, ex);
        }
        
        
        } catch (Exception e) {
            e.printStackTrace();
        }
        }else if(branch.equals("Chem"))
        {
            Connection con = null;
        String url = "jdbc:mysql://localhost:3306/";;
        String db = "codex";
        String driver = "com.mysql.jdbc.Driver";
        String user = "CHETAN";
        String pass = "Micro@123";
        String user1 = "";
        String pass1 = "";
        try {
            Class.forName(driver);
            con = (Connection) DriverManager.getConnection(url + db, user, pass);
            Statement st = (Statement) con.createStatement();

           // int k = st.executeUpdate("insert into login(email) values('" + email + "')");
            int k = st.executeUpdate("insert into  chem(fname,mname,lname,contact_no,email,dob,address,city,state,course,fees) values('" + fname + "','" + mname + "','" + lname + "','" + contact + "','" + email + "','" + dob + "','" + address + "','" + city + "','" + state + "','" + course + "','" + fees + "');");
            JOptionPane.showMessageDialog(null, "Data saved successfully .");
            
             Parent root=null;
        try {
              root = FXMLLoader.load(getClass().getResource("/homescreen/Home.fxml"));
            
             Scene scene = new Scene(root);
            Stage stage=new Stage();
            stage.setScene(scene);
           cb_course.getScene().getWindow().hide();
            stage.show();

        } catch (IOException ex) {
            Logger.getLogger(Codexx.class.getName()).log(Level.SEVERE, null, ex);
        }
        
        } catch (Exception e) {
            e.printStackTrace();
        }
            
        }
        else
        {
            JOptionPane.showMessageDialog(null,"Unable to process data");
        }
    }


    
}
