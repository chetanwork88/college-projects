/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package homescreen;

import codexx.Codexx;
import com.mysql.jdbc.Connection;
import com.mysql.jdbc.Statement;
import java.awt.Checkbox;
import java.io.IOException;
import java.net.URL;
import java.sql.DriverManager;
import java.util.ResourceBundle;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.CheckBox;
import javafx.scene.control.ComboBox;
import javafx.scene.control.TextField;
import javafx.scene.image.ImageView;
import javafx.stage.Stage;
import javax.swing.JOptionPane;

/**
 * FXML Controller class
 *
 * @author Chetan
 */
public class ClubsController implements Initializable {

    @FXML
    private ImageView Anch;
    @FXML
    private CheckBox GooFox;
    @FXML
    private CheckBox IgnMinds;
    @FXML
    private CheckBox ShutPhoto;
    @FXML
    private CheckBox WebDev;
    @FXML
    private CheckBox MastBlast;
    @FXML
    private CheckBox Hackrank;
    @FXML
    private CheckBox Robocon;
    @FXML
    private CheckBox maths;
    @FXML
    private CheckBox Baja;
    @FXML
    private ComboBox<String> cb_course;
    @FXML
    private ComboBox<String> cb_branch;
    @FXML
    private TextField tf_rollno;
   

    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
        
        cb_branch.getItems().addAll("CS", "IT", "Mech", "ENTC", "ETX", "Civil", "Chem");
            cb_course.getItems().addAll("First Year", "Second Year", "Third Year", "Fourth Year");
        
    }    

    @FXML
    private void ActionBySubmitButton(ActionEvent event) {
        
        String str ="";
        if(GooFox.isSelected())
        {
            str+="Google Student & Firefox    ";
       
        }
        
        if(IgnMinds.isSelected())
        {
            str+="Ignited Minds    ";
       
        }
        
        if(ShutPhoto.isSelected())
        {
            str+="Shutterbugs Photography    ";
       
        }
        
       if(WebDev.isSelected())
        {
            str+="LabelProgramming & Web Development   ";
       
        }
       
       if(MastBlast.isSelected())
        {
            str+="MIT Master Blasters Sports Club   ";
       
        }
       
       if(Hackrank.isSelected())
        {
            str+="Hacker Rank   ";
       
        }
       
       if(Robocon.isSelected())
        {
            str+="Robocon    ";
       
        }
       
       if(maths.isSelected())
        {
            str+="Maths   ";
       
        }
       
       if(Baja.isSelected())
        {
            str+="Baja   ";
       
        }
       
        String dept=cb_branch.getValue();
        String year=cb_course.getValue();
        String rollno = tf_rollno.getText();
        
        
        Connection con = null;
        String url = "jdbc:mysql://localhost:3306/";;
        String db = "codex";
        String driver = "com.mysql.jdbc.Driver";
        String user = "CHETAN";
        String pass = "Micro@123";

        try {
            Class.forName(driver);
            con = (Connection) DriverManager.getConnection(url + db, user, pass);
            Statement st = (Statement) con.createStatement();

            
            int k = st.executeUpdate("insert into club(dept,year,Rollno,clubs_joined) values('" + dept + "','" + year + "','" + rollno + "','" + str + "');");
            JOptionPane.showMessageDialog(null, "Data updated successfully .");

            Parent root = null;
            try {
                root = FXMLLoader.load(getClass().getResource("/homescreen/Home.fxml"));

                Scene scene = new Scene(root);
                Stage stage = new Stage();
                stage.setScene(scene);
                Anch.getScene().getWindow().hide();
                stage.show();

            } catch (IOException ex) {
                Logger.getLogger(Codexx.class.getName()).log(Level.SEVERE, null, ex);
            }
        } catch (Exception e) {
            System.out.println(e);
            JOptionPane.showMessageDialog(null, "Enter valid credentials .");

        }
        
        
        
        
        
        
        
           }

    
}
