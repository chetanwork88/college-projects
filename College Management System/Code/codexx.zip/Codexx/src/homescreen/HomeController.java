/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package homescreen;

import codexx.Codexx;
import com.mysql.jdbc.Connection;
import com.mysql.jdbc.Statement;
import java.io.IOException;
import java.net.URL;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ResourceBundle;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.ComboBox;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.image.ImageView;
import javafx.stage.Stage;
import javax.swing.JOptionPane;
import t_homescreen.TeacherHomeController;



/**
 * FXML Controller class
 *
 * @author Chetan
 */
public class HomeController implements Initializable {


    @FXML
    private TextField result_tf_rollno;
    @FXML
    private TextField tf_atten_rollno;
    @FXML
    private ComboBox<String> cb_attend_dept;
    @FXML
    private ComboBox<String> cb_attend_course;
    @FXML
    private ComboBox<String> cb_result_dept;
    @FXML
    private ComboBox<String> cb_result_course;
    @FXML
    private ImageView Anch;
    @FXML
    private ImageView Anch1;
    @FXML
    private ImageView Anch11;
    @FXML
    private Label lb_attend_attend;
    @FXML
    private ComboBox<String> cb_attend_subject;
            String Attend_dept;
            String Attend_course;
            String Attend_rollno;
    @FXML
    private ComboBox<String> cb_result_subject;
    
            String result_dept;
            String result_course;
            String result_rollno;
    @FXML
    private Label lb_marks_result;
    @FXML
    private ComboBox<String> cb_library;

    
    //intialize the bookin combobox
    
    
    

    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        
        // TODO
       cb_attend_dept.getItems ().addAll("CS","IT","Mech","ENTC","ETX","Civil","Chem");
        cb_attend_course.getItems ().addAll("First Year","Second Year","Third Year","Fourth Year");
    
    cb_result_dept.getItems ().addAll("CS","IT","Mech","ENTC","ETX","Civil","Chem");
    cb_result_course.getItems ().addAll("First Year","Second Year","Third Year","Fourth Year");

        
    try{
        Connection con = null;
            String url1 = "jdbc:mysql://localhost:3306/";
            String db = "codex";
            String driver = "com.mysql.jdbc.Driver";
            String user = "CHETAN";
            String pass = "Micro@123";
            
            
            
            con = (Connection) DriverManager.getConnection(url1 + db, user, pass);
            Statement st = (Statement) con.createStatement();
            ResultSet res= st.executeQuery("select bname from library ;");
            while(res.next())
                    {
                        cb_library.getItems().addAll(res.getString(1));
                    }
        } catch (SQLException ex) {
            Logger.getLogger(TeacherHomeController.class.getName()).log(Level.SEVERE, null, ex);
        }
    }    

   
    @FXML
    private void ActionByApplyHereAdmission(ActionEvent event) {
        Parent root=null;
        try {
              root = FXMLLoader.load(getClass().getResource("/homescreen/AdmissionForm.fxml"));
            
             Scene scene = new Scene(root);
            Stage stage=new Stage();
            stage.setScene(scene);
          Anch.getScene().getWindow().hide();
            stage.show();

        } catch (IOException ex) {
            Logger.getLogger(Codexx.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    @FXML
    private void ActionBySignOut(ActionEvent event) {
        Parent root=null;
        try {
              root = FXMLLoader.load(getClass().getResource("/codexx/MainFrame.fxml"));
            
             Scene scene = new Scene(root);
            Stage stage=new Stage();
            stage.setScene(scene);
           Anch.getScene().getWindow().hide();
            stage.show();

        } catch (IOException ex) {
            Logger.getLogger(Codexx.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    @FXML
    private void ActionByNoSignOut(ActionEvent event) {
        
        Parent root=null;
        try {
              root = FXMLLoader.load(getClass().getResource("/homescreen/Home.fxml"));
            
             Scene scene = new Scene(root);
            Stage stage=new Stage();
            stage.setScene(scene);
           Anch.getScene().getWindow().hide();
            stage.show();

        } catch (IOException ex) {
            Logger.getLogger(Codexx.class.getName()).log(Level.SEVERE, null, ex);
        }
        
    }

    
    @FXML
    private void ActionByCheckHereAttendence(ActionEvent event) {
        
        JOptionPane.showMessageDialog(null,"Select the subject from below");
        try {
 Attend_dept=cb_attend_dept.getValue();
 Attend_course=cb_attend_course.getValue();
 Attend_rollno=tf_atten_rollno.getText();
            
            
            Connection con = null;
            String url1 = "jdbc:mysql://localhost:3306/";
            String db = "codex";
            String driver = "com.mysql.jdbc.Driver";
            String user = "CHETAN";
            String pass = "Micro@123";
            
            
            
            con = (Connection) DriverManager.getConnection(url1 + db, user, pass);
            Statement st = (Statement) con.createStatement();
            ResultSet res= st.executeQuery("select subject from attendence where dept= '"+Attend_dept+"' and course='"+Attend_course+"' and Roll_no='"+Attend_rollno+"';");
            while(res.next())
            {
                cb_attend_subject.getItems().addAll(res.getString(1));
            }
               } catch (SQLException ex) {
            Logger.getLogger(TeacherHomeController.class.getName()).log(Level.SEVERE, null, ex);
        }

        
        
        
    }

    @FXML
    private void ActionByOKButtonAttendence(ActionEvent event) {
        
        Parent root=null;
        try {
              root = FXMLLoader.load(getClass().getResource("/homescreen/Home.fxml"));
            
             Scene scene = new Scene(root);
            Stage stage=new Stage();
            stage.setScene(scene);
           Anch.getScene().getWindow().hide();
            stage.show();

        } catch (IOException ex) {
            Logger.getLogger(Codexx.class.getName()).log(Level.SEVERE, null, ex);
        }
        
    }

    @FXML
    private void ActionByCheckHereResult(ActionEvent event) {
        
        
        
         JOptionPane.showMessageDialog(null,"Select the subject from below");
        try {
         result_dept=cb_result_dept.getValue();
        result_course=cb_result_course.getValue();
         result_rollno=result_tf_rollno.getText();
            
            
            Connection con = null;
            String url1 = "jdbc:mysql://localhost:3306/";
            String db = "codex";
            String driver = "com.mysql.jdbc.Driver";
            String user = "CHETAN";
            String pass = "Micro@123";
            
            
            
            con = (Connection) DriverManager.getConnection(url1 + db, user, pass);
            Statement st = (Statement) con.createStatement();
            ResultSet res= st.executeQuery("select subject from result where dept= '"+result_dept+"' and course='"+result_course+"' and Roll_no='"+result_rollno+"';");
            while(res.next())
            {
              cb_result_subject.getItems().addAll(res.getString(1));
            }
               } catch (SQLException ex) {
            Logger.getLogger(TeacherHomeController.class.getName()).log(Level.SEVERE, null, ex);
        }
        
    }

    @FXML
    private void ActionByOKButtonResult(ActionEvent event) {
        
        Parent root=null;
        try {
              root = FXMLLoader.load(getClass().getResource("/homescreen/Home.fxml"));
            
             Scene scene = new Scene(root);
            Stage stage=new Stage();
            stage.setScene(scene);
           Anch.getScene().getWindow().hide();
            stage.show();

        } catch (IOException ex) {
            Logger.getLogger(Codexx.class.getName()).log(Level.SEVERE, null, ex);
        }
        
    }

    @FXML
    private void ActionByAttend_Subject(ActionEvent event) {
        
        try {
            Connection con = null;
            String url1 = "jdbc:mysql://localhost:3306/";
            String db = "codex";
            String driver = "com.mysql.jdbc.Driver";
            String user = "CHETAN";
            String pass = "Micro@123";
            
            
            
            con = (Connection) DriverManager.getConnection(url1 + db, user, pass);
            Statement st = (Statement) con.createStatement();
            ResultSet res= st.executeQuery("select attendence from attendence where dept= '"+Attend_dept+"' and course='"+Attend_course+"' and Roll_no='"+Attend_rollno+"' and subject='"+cb_attend_subject.getValue()+"';");
            if(res.next())
            {
               lb_attend_attend.setText(res.getString(1));
            }
            else
            {
                JOptionPane.showMessageDialog(null,"Enter valid Credentials");
            }
        } catch (SQLException ex) {
            Logger.getLogger(HomeController.class.getName()).log(Level.SEVERE, null, ex);
           
        }
        
        
        
        
    }

    @FXML
    private void ActionByResultSubject(ActionEvent event) {
        
        try {
            Connection con = null;
            String url1 = "jdbc:mysql://localhost:3306/";
            String db = "codex";
            String driver = "com.mysql.jdbc.Driver";
            String user = "CHETAN";
            String pass = "Micro@123";
            
            
            
            con = (Connection) DriverManager.getConnection(url1 + db, user, pass);
            Statement st = (Statement) con.createStatement();
            ResultSet res= st.executeQuery("select marks from result where dept= '"+result_dept+"' and course='"+result_course+"' and Roll_no='"+result_rollno+"' and subject='"+cb_result_subject.getValue()+"';");
            if(res.next())
            {
               lb_marks_result.setText(res.getString(1));
            }
            else
            {
                JOptionPane.showMessageDialog(null,"Enter valid Credentials");
       
            }
        } catch (SQLException ex) {
            Logger.getLogger(HomeController.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    @FXML
    private void ActionBySearchBook(ActionEvent event) {
        
        String book = cb_library.getValue();
        String quantity = "1";
        Connection con = null;
        String url = "jdbc:mysql://localhost:3306/";
        String db = "codex";
        String driver = "com.mysql.jdbc.Driver";
        String user = "CHETAN";
        String pass = "Micro@123";

        try {
            //Class.forName(driver);
            con = (Connection) DriverManager.getConnection(url + db, user, pass);
            Statement st = (Statement) con.createStatement();

            // int k = st.executeUpdate("insert into login(email) values('" + email + "')");
//            int k = st.executeUpdate("insert into  civil(fname,mname,lname,contact_no,email,dob,address,city,state,course,fees) values('" + fname + "','" + mname + "','" + lname + "','" + contact + "','" + email + "','" + dob + "','" + address + "','" + city + "','" + state + "','" + course + "','" + fees + "');");
            ResultSet us = st.executeQuery("select qty from library where bname = '" + book + "';");
            if (us.next()) {
                // ResultSet res = st.executeQuery("select * from library where banme = '" + book + "';");

                // if (res.next()) {
                // System.out.println("hello");
                if (Integer.parseInt(us.getString(1)) > 0) {

                    JOptionPane.showMessageDialog(null, "Book Is Avaialable In Library...");
                } 
                else {          
                    JOptionPane.showMessageDialog(null, "Book Is Not Avaialable In Library...");
                }
            } else {
                JOptionPane.showMessageDialog(null, "Enter Correct Book Name");
            }
        } catch (Exception e) {
            e.printStackTrace();
            
        }
    }

    @FXML
    private void ActionByClubClickHere(ActionEvent event) {
        
        Parent root=null;
        try {
              root = FXMLLoader.load(getClass().getResource("/homescreen/Clubs.fxml"));
            
             Scene scene = new Scene(root);
            Stage stage=new Stage();
            stage.setScene(scene);
           Anch.getScene().getWindow().hide();
            stage.show();

        } catch (IOException ex) {
            Logger.getLogger(Codexx.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    @FXML
    private void ActionByHostelApplyHere(ActionEvent event) {
        
        JOptionPane.showMessageDialog(null,"Kindly Visit College Management to get admission");
    }


    
}
